import datetime
import sqlalchemy
from .db_session import SqlAlchemyBase


class Jobs(SqlAlchemyBase):
    __tablename__ = 'jobs'

    id = sqlalchemy.Column(sqlalchemy.Integer,
                           primary_key=True, autoincrement=True)
    team_leader = sqlalchemy.Column(sqlalchemy.Integer,
                                    sqlalchemy.ForeignKey("users.id"))
    job = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    work_size = sqlalchemy.Column(sqlalchemy.Integer, nullable=True)
    collaborators = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    start_date = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    end_date = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    is_finished = sqlalchemy.Column(sqlalchemy.Boolean, nullable=True)

    def __init__(self, __tablename__, id, team_lader, job, work_size, collaborators, start_date,
                 end_date, is_finished):
        self.__tablename__ = __tablename__

        self.id = id
        self.team_lader = team_lader
        self.job = job
        self.age = age
        self.work_size = work_size
        self.collaborators = collaborators
        self.start_date = start_date
        self.end_date = end_date
        self.is_finished = is_finished


 #   def __repr__(self):
#        return f"<Colonist> {self.id} {self.surname} {self.name}"
